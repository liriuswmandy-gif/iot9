#include <WiFi.h>
#include <WebServer.h>
#include <ESP32Servo.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

// Credenciais da rede Wi-Fi que o ESP32 vai criar
const char* ssid = "Estacionamento_ESP32";
const char* password = "12345678"; // Mínimo de 8 caracteres

WebServer server(80);

// Configuração do Display OLED (128x64)
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET    -1
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

// Definição dos pinos (mantendo o último padrão do seu circuito)
#define TRIG_PIN 12   
#define ECHO_PIN 14   
#define SERVO_PIN 23  
#define LED_PIN 4     

Servo meuservo;
long distance = 0;

// Página HTML que será exibida quando você acessar o IP do ESP32 no navegador
void handleRoot() {
  String html = "<!DOCTYPE html><html><head>";
  html += "<meta charset=\"UTF-8\">";
  html += "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">";
  html += "<title>Estacionamento Inteligente</title>";
  html += "<style>";
  html += "body { font-family: Arial, sans-serif; text-align: center; margin-top: 50px; background-color: #f4f4f9; }";
  html += "h1 { color: #333; }";
  html += ".card { background: white; padding: 20px; border-radius: 10px; box-shadow: 0px 0px 10px rgba(0,0,0,0.1); display: inline-block; }";
  html += ".status { font-size: 24px; font-weight: bold; margin: 20px 0; }";
  html += ".vaga { color: green; } .ocupado { color: red; }";
  html += "</style>";
  html += "<meta http-equiv=\"refresh\" content=\"2\">"; // Atualiza a página a cada 2 segundos
  html += "</head><body>";
  html += "<div class=\"card\">";
  html += "<h1>Estacionamento ESP32</h1>";
  html += "<p>Distancia do veiculo:</p>";
  html += "<h2>" + String(distance) + " cm</h2>";
  html += "<div class=\"status\">Status: ";
  if (distance < 100) {
    html += "<span class=\"ocupado\">CARRO DETECTADO (Cancela Aberta)</span>";
  } else {
    html += "<span class=\"vaga\">LIVRE (Cancela Fechada)</span>";
  }
  html += "</div></div></body></html>";
  
  server.send(200, "text/html", html);
}

void setup() {
  Serial.begin(9600);
  
  // Configuração dos pinos
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);
  pinMode(LED_PIN, OUTPUT);
  
  // Inicialização do Servo e OLED
  meuservo.attach(SERVO_PIN);
  meuservo.write(0);
  digitalWrite(LED_PIN, LOW);

  if(!display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
    Serial.println(F("Falha ao inicializar o OLED"));
    for(;;);
  }
  
  display.clearDisplay();
  display.setTextColor(WHITE);

  // Configurando o ESP32 como Ponto de Acesso (Access Point)
  Serial.println("Configurando o Access Point (AP)...");
  WiFi.softAP(ssid, password);
  
  IPAddress myIP = WiFi.softAPIP();
  Serial.print("IP do Access Point: ");
  Serial.println(myIP);

  // Rotas do Servidor Web
  server.on("/", handleRoot);
  server.begin();
  Serial.println("Servidor Web iniciado!");
}

void loop() {
  server.handleClient(); // Controla as requisições dos clientes conectados

  long duration;

  // Emitir pulso ultrassônico
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);

  duration = pulseIn(ECHO_PIN, HIGH);
  distance = (duration / 2) * 0.0343;

  // Lógica de acionamento (< 100 cm)
  if (distance < 100) {
    digitalWrite(LED_PIN, HIGH); 
    meuservo.write(90);          
  } else {
    digitalWrite(LED_PIN, LOW);  
    meuservo.write(0);           
  }

  // Atualizar Display OLED
  display.clearDisplay();
  display.setTextSize(1);
  display.setCursor(0, 0);
  display.println("MODO AP WEB SERVER");
  display.drawLine(0, 10, 128, 10, WHITE);

  display.setCursor(0, 15);
  display.print("Rede: ");
  display.println(ssid);

  display.setCursor(0, 27);
  display.print("IP: 192.168.4.1");

  display.setCursor(0, 42);
  display.print("Dist: ");
  display.print(distance);
  display.println(" cm");

  display.setCursor(0, 54);
  if (distance < 100) {
    display.println("Status: CARRO DETECTADO");
  } else {
    display.println("Status: VAGA LIVRE");
  }
  
  display.display();

  delay(500);
}